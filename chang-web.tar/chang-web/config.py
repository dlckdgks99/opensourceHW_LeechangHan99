import os

# session secret
SECRET_KEY = 'secret'

# db config
SQLALCHEMY_DATABASE_URI = 'mysql://{}:{}@{}:{}/{}'.format(
    os.environ['DATABASE_USER'],
    os.environ['DATABASE_PASSWORD'],
    os.environ['DATABASE_SERVER'],
    os.environ['DATABASE_PORT'],
    os.environ['DATABASE']
)

SMARTSW_HOST = os.environ['SMARTSW_HOST']